#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random

__author__ = "Your name & student number here"

# Write your classes here


def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()
